// String url = '192.168.10.5:8083';
String url = '135.235.216.175:8080';
String kServerUrl = 'http://$url/predict/';
String kPingUrl = 'http://$url/ping';
// const String kServerUrl = 'http://135.235.216.175:8080/predict/';
